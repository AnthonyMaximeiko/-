{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "117829b9-6bd0-4e40-a7b3-cc479eceed48",
   "metadata": {},
   "outputs": [],
   "source": [
    "WITH Packages AS (\n",
    "  SELECT\n",
    "    OrderNumber,\n",
    "    Moment,\n",
    "    PackageName,\n",
    "    ROW_NUMBER() OVER (PARTITION BY OrderNumber ORDER BY Moment DESC) AS RowNum\n",
    "  FROM\n",
    "    MyTable\n",
    ")\n",
    "SELECT\n",
    "  OrderNumber,\n",
    "  Moment AS ChosenMoment,\n",
    "  PackageName\n",
    "FROM\n",
    "  RankedPackages\n",
    "WHERE\n",
    "  RowNum = 1"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "anaconda-panel-2023.05-py310",
   "language": "python",
   "name": "conda-env-anaconda-panel-2023.05-py310-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
