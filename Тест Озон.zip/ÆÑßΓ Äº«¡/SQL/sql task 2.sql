{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "52f3974d-6e02-4e63-a435-3c1e7c09efcd",
   "metadata": {},
   "outputs": [],
   "source": [
    "WITH Carriages AS (\n",
    "  SELECT\n",
    "    CarriageID,\n",
    "    SUM(Volume) AS TotalVolume,\n",
    "    ROW_NUMBER() OVER (ORDER BY SUM(Volume) DESC) AS RowNum\n",
    "  FROM\n",
    "    MyTable\n",
    "  WHERE\n",
    "    CAST(MomentOut AS DATETIME) >= DATEADD(MONTH, -1, GETDATE())\n",
    "  GROUP BY\n",
    "    CarriageID\n",
    ")\n",
    "SELECT TOP 10 PERCENT\n",
    "  C.CarriageID,\n",
    "  C.TotalVolume\n",
    "FROM\n",
    "  Carriages AS C\n",
    "WHERE\n",
    "  C.RowNum <= 10\n",
    "ORDER BY\n",
    "  C.TotalVolume DESC"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "anaconda-panel-2023.05-py310",
   "language": "python",
   "name": "conda-env-anaconda-panel-2023.05-py310-py"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.11.5"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
